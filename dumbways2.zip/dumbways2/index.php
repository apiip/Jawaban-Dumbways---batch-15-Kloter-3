<?php 
    require("./config/db.php");

    $baca = mysqli_query($koneksi, "SELECT nama, diresmikan FROM tblbuku");
    $data = mysqli_query($koneksi, "SELECT * FROM tblbuku");
    // kalo buat kombo box pilihan pake fetch all enak
    $categories = mysqli_fetch_all($data, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Homepage</title>
</head>
<body>
<!-- start nav -->
<br>
<div class="container">
<h1>Dumb Library</h1> <br>
    <ul class="nav justify-content-end">
        <li class="">
        <a class="btn-primary bttn" href="./pages/cbuku.php">Add buku</a>
        </li>
        <li class="">
        <a class="btn-danger bttn" href="./pages/cpenulis.php">Add penulis</a>
        </li>
        <li class="">
        <a class="btn-danger bttn" href="./pages/ckat.php">Add kategori</a>
        </li>
    </ul>
</div>
<br><br>
<!-- end nav -->
<!-- start content -->
   
<!-- isi -->

<div class="row container pager">
<?php if (mysqli_num_rows($data) > 0) { ?>
    <?php foreach($categories as $category) { ?>
        <div class="col-md4 pager">
        <div class="card" style="width: 20rem;">
        
            <img src="./foto/download.png" class="card-img-top" alt="...">
            <div class="card-body">
            <h5 class="card-title"><?php echo $category['nama']; ?></h5>
            <a href="./pages/detail.php?id=<?=$category['id']?>" class="btn btn-primary">detail</a>
            </div>
        
        </div>
        </div>
    <?php } ?>

<?php } else { ?>
        <h1> Maaf Belum Ada Data, Silahkan Ditambahkan </h1>
<?php } ?>

</div>

<!-- end content -->

</body>


<!-- script -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<!-- end script -->
</html>