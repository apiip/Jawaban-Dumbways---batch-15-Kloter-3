<?php 
   $koneksi = mysqli_connect("localhost", "root", "", "dbway2");

   if (!$koneksi) {
       echo "gagal koneksi";
   }
?>