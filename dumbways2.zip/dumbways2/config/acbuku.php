<?php 
    require('db.php');

    $nama = $_POST['nama'];
    $tanggal = $_POST['tanggal'];
    $jenis = $_POST['jenis'];
    $penulis = $_POST['penulis'];

    mysqli_query($koneksi, "INSERT INTO tblbuku(nama,idcat,idwrite,pubyear) VALUES('$nama','$jenis','$penulis','$tanggal')");

    // redirect
    header('location: ../index.php')
?>