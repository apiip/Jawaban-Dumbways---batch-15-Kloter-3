<?php 
    require('db.php');

    $nama = $_POST['nama'];
    mysqli_query($koneksi, "INSERT INTO tblwrite(nama) VALUES('$nama')");

    // redirect
    header('location: ../pages/penulis.php')
?>