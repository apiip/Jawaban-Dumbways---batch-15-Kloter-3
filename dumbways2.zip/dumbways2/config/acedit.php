<?php 
    require("db.php");

    $title = $_POST['nama'];
    $content = $_POST['jenis'];
    $category_id = $_POST['penulis'];
    $id = $_POST['id'];

    mysqli_query($koneksi, "UPDATE tblbuku SET nama ='$title', idcat ='$content', idwrite ='$category_id' WHERE id = $id ");

    header('location: ../index.php')
?>