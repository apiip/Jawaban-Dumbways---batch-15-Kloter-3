-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Mar 2020 pada 08.54
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbway2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblbuku`
--

CREATE TABLE `tblbuku` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `idcat` int(11) NOT NULL,
  `idwrite` int(11) NOT NULL,
  `pubyear` date NOT NULL,
  `img` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tblbuku`
--

INSERT INTO `tblbuku` (`id`, `nama`, `idcat`, `idwrite`, `pubyear`, `img`) VALUES
(2, 'Basic PHP', 2, 1, '2020-03-10', 0),
(3, 'Basic UI/UX', 4, 4, '2020-03-17', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblcat`
--

CREATE TABLE `tblcat` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tblcat`
--

INSERT INTO `tblcat` (`id`, `nama`) VALUES
(1, 'FrondEnd'),
(2, 'BackEnd'),
(3, 'Design'),
(4, 'UI/UX');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblwrite`
--

CREATE TABLE `tblwrite` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tblwrite`
--

INSERT INTO `tblwrite` (`id`, `nama`) VALUES
(1, 'Sandhika'),
(2, 'Angga'),
(3, 'Rio'),
(4, 'Kukuh');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tblbuku`
--
ALTER TABLE `tblbuku`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tblcat`
--
ALTER TABLE `tblcat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tblwrite`
--
ALTER TABLE `tblwrite`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tblbuku`
--
ALTER TABLE `tblbuku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tblcat`
--
ALTER TABLE `tblcat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tblwrite`
--
ALTER TABLE `tblwrite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
