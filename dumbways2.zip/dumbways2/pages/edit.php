<?php
    require("../config/db.php");

    $data = mysqli_query($koneksi, "SELECT * FROM tblcat");
    // kalo buat looping pilihan pake fetch all enak
    $categories = mysqli_fetch_all($data, MYSQLI_ASSOC);

    $data2 = mysqli_query($koneksi, "SELECT * FROM tblwrite");
    // kalo buat looping pilihan pake fetch all enak
    $penulis = mysqli_fetch_all($data2, MYSQLI_ASSOC);

    // var_dump($categories)
    $id = $_GET['id'];
    $edit = mysqli_query($koneksi, "SELECT * FROM tblbuku where id = $id");
    $edit = mysqli_fetch_assoc($edit);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Article</title>
</head>
<body>
    <h2>Edit Data Buku</h2>

    <form method="POST" action="../config/acedit.php">
        <p>
        <label for="">Nama</label><br>
        <input type="text" name="nama" value="<?=$edit['nama'] ?>">
        </p>

        <p>
        <label for="">Jenis</label><br>
        <select name="jenis" id="">
            <?php foreach($categories as $category) { ?>
              <option value="<?php echo $category['id']; ?>" 
              
              <?= $category['id'] == $edit['idcat'] ? 'selected' : '' ?>
              >
              
              <?php echo $category['nama']; ?> 
              </option>  
            <?php } ?>
        </select>
        </p>


        <p>
        <label for="">Penulis</label><br>
        <select name="penulis" id="">
            <?php foreach($penulis as $category) { ?>
              <option value="<?php echo $category['id']; ?>" 
              
              <?= $category['id'] == $edit['idwrite'] ? 'selected' : '' ?>
              >
              
              <?php echo $category['nama']; ?> 
              </option>  
            <?php } ?>
        </select>
        </p>

        <input type="hidden" name="id" value="<?= $id ?>">

        <p><input type="submit" value="Edit Data"></p>
        <a href="../index.php">Batal</a>
    </form>
</body>
</html>