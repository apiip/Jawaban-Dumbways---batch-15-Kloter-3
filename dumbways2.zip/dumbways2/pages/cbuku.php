<?php
    require("../config/db.php");

    $data = mysqli_query($koneksi, "SELECT * FROM tblcat");
    // kalo buat kombo box pilihan pake fetch all enak
    $categories = mysqli_fetch_all($data, MYSQLI_ASSOC);

    $data2 = mysqli_query($koneksi, "SELECT * FROM tblwrite");
    // kalo buat kombo box pilihan pake fetch all enak
    $penulis = mysqli_fetch_all($data2, MYSQLI_ASSOC);

    // var_dump($categories)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Create Buku</title>
</head>
<body>
<div class="card">
<div class="card-header">
    <h2>Create Buku</h2>
</div>
<div class="card-body">
    <form method="POST" action="../config/acbuku.php">
        <p>
        <label for="">Nama</label><br>
        <input type="text" name="nama">
        </p>
    
        <p>
        <label for="">Tanggal</label><br>
        <input type="date" name="tanggal">
        </p>

        <div class="form-group">
        <p>
        <label for="">Jenis</label><br>
        <select name="jenis" id="">
            <?php foreach($categories as $category) { ?>
              <option value="<?php echo $category['id']; ?>"><?php echo $category['nama']; ?> </option>  

            <?php } ?>
        </select>
        </p>
        </div>

        <p>
        <label for="">Penulis</label><br>
        <select name="penulis" id="">
            <?php foreach($penulis as $penulis) { ?>
              <option value="<?php echo $penulis['id']; ?>"><?php echo $penulis['nama']; ?> </option>  

            <?php } ?>
        </select>
        </p>
        <input type="submit" value="Buat Data" class="btn btn-primary">
        <a href="../index.php" class="btn btn-link">Lihat Data</a>
    </form>
</div>
</div>


</body>
</html>