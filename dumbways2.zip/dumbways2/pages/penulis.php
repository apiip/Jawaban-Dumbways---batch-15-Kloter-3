<?php 
    require("../config/db.php");

    $baca = mysqli_query($koneksi, "SELECT * FROM tblwrite ORDER BY id asc ");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Halaman Utama</title>
</head>
<body>
<br>
<div class="container">
    <h1>List Penulis</h1>
    <?php if (mysqli_num_rows($baca) > 0) { ?>
    <table cellpadding="5" border="1" cellspacing="0" width="50%">
        <thead>
            <tr>
                <th>Nama</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($article = mysqli_fetch_assoc($baca)) { ?>
            
            <tr>
                <td><?= $article['nama']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    <?php } else { ?>
        <h1> Data Kosong </h1>
    <?php } ?>
    <br>
    <a href="./cpenulis.php" class="btn btn-primary"> Bikin Data Baru!!</a>
</div>
</body>
</html>